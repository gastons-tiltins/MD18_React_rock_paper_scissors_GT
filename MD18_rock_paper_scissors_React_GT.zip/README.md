# Rock Paper Scissors game in 3 languages
# Score saved to MySQL database trough API

### `npm run dev`
